﻿namespace Tarea2.Models
{
	public class Cabecera
	{
		public int ID { get; set; }
		public string? Nombre { get; set; }
		public decimal Longitud { get; set; }
		public decimal Latitud { get; set; }
		public string? Imagen { get; set; }
	}
}
